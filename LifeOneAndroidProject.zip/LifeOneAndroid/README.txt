LIFEONE ANDROID PROJECT (SOURCE, NOT A BUILT APK)

This project wraps the LifeOne HTML prototype in an Android WebView.
It does not require a purchased domain or internet connection for the main app screen.

HOW TO BUILD AN APK:
1. Copy this ZIP to a computer with Android Studio installed.
2. Extract the ZIP.
3. In Android Studio, choose Open and select the extracted LifeOneAndroid folder.
4. Let Gradle sync complete.
5. Choose Build > Build APK(s).
6. Find the debug APK in app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to your Android phone and install it. Android may ask you to allow installs from that file manager.

NOTES:
- This ZIP is Android Studio source code, not an APK file.
- The built-in assistant is an offline demo, not a connected AI model.
- Tasks and notes are stored locally by the WebView/browser storage.
- Do not install APKs from unknown websites. Build this source yourself or have a trusted developer build it.
